from setuptools import setup
setup(name="kuchnhi_package",
      version="0.2",
      description="this is my first custom python package",
      long_description="this is a very long description of my first custom python package",
      author="sk8",
      packages=['kuchnhi_package'],
      install_requires=[])