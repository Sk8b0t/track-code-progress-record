def tmkc(n):
    print("teri mkc 10 bar ")
    return n
